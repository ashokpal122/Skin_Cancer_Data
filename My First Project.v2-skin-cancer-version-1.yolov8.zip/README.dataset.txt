# My First Project > Skin Cancer Version 1
https://universe.roboflow.com/emon-pal-xquax/my-first-project-cwbdc

Provided by a Roboflow user
License: CC BY 4.0

